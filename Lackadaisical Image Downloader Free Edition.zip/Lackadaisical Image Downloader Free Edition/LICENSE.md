# Lackadaisical Restricted Use License

Copyright (c) 2025 Lackadaisical Security

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to use
and modify the Software for personal use only, subject to the following conditions:

1. The above copyright notice and this permission notice shall be included in all
   copies or modifications of the Software.

2. Any modifications of this code must contain the original license and
   properly attribute the original work to "Lackadaisical Image Downloader - Free Edition"
   by Lackadaisical Security (https://lackadaisical-security.com).

3. The Software may not be sold, distributed, sublicensed, published, or
   transferred in any form without explicit written permission from Lackadaisical Security.

4. Users may modify the Software for their own personal use only, without
   requiring additional licensing from Lackadaisical Security.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
