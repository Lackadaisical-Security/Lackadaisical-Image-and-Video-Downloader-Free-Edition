/**
 * Image processing utility for Lackadaisical Image Downloader - Free Edition
 * Copyright (c) 2025 Lackadaisical Security
 * https://lackadaisical-security.com
 */

const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

/**
 * Process an image file with various options
 * 
 * @param {string} inputPath - Path to the input image file
 * @param {object} options - Processing options
 * @param {boolean} options.stripMetadata - Whether to strip metadata from the image
 * @param {string} options.format - Format to convert to (null for original)
 * @param {number} options.quality - Quality for lossy formats (1-100)
 * @returns {Promise<string>} - Path to the processed file
 */
async function processImage(inputPath, options = {}) {
  if (!fs.existsSync(inputPath)) {
    throw new Error('Input file does not exist');
  }
  
  // Default options
  const {
    stripMetadata = true,
    format = null,
    quality = 85
  } = options;
  
  try {
    let image = sharp(inputPath);
    const metadata = await image.metadata();
    
    // Validate supported formats
    const supportedInputFormats = ['jpeg', 'jpg', 'png', 'webp', 'tiff', 'gif', 'svg', 'avif'];
    if (!metadata.format || !supportedInputFormats.includes(metadata.format.toLowerCase())) {
      throw new Error(`Unsupported image format: ${metadata.format || 'unknown'}`);
    }
    
    // Process based on options
    if (stripMetadata) {
      // Remove all metadata
      image = image.withMetadata({ exif: {} });
    }
    
    // Format conversion if requested
    const supportedOutputFormats = ['jpeg', 'png', 'webp', 'avif'];
    if (format) {
      // Validate format is supported
      if (!supportedOutputFormats.includes(format.toLowerCase())) {
        throw new Error(`Unsupported output format: ${format}`);
      }
      
      switch(format.toLowerCase()) {
        case 'jpeg':
          image = image.jpeg({ quality });
          break;
        case 'png':
          image = image.png({ quality: Math.floor(quality / 10) || 8 });
          break;
        case 'webp':
          image = image.webp({ quality });
          break;
        case 'avif':
          image = image.avif({ quality });
          break;
        default:
          // Use original format if somehow the validation is bypassed
          console.warn(`Unhandled format ${format}, using original format`);
          break;
      }
    }
    
    // Create output filename
    const parsedPath = path.parse(inputPath);
    const newExt = format ? `.${format.toLowerCase()}` : parsedPath.ext;
    let outputFilename = `${parsedPath.name}_processed${newExt}`;
    let outputPath = path.join(parsedPath.dir, outputFilename);
    
    // Handle case where output file already exists
    let counter = 1;
    while (fs.existsSync(outputPath)) {
      outputFilename = `${parsedPath.name}_processed_${counter}${newExt}`;
      outputPath = path.join(parsedPath.dir, outputFilename);
      counter++;
    }
    
    // Save processed image
    await image.toFile(outputPath);
    console.log(`Image processed successfully: ${outputPath}`);
    return outputPath;
  } catch (error) {
    console.error('Error processing image:', error);
    throw new Error(`Failed to process image: ${error.message}`);
  }
}

module.exports = {
  processImage
};
