/**
 * Lackadaisical Image Downloader - Free Edition
 * Copyright (c) 2025 Lackadaisical Security
 * https://lackadaisical-security.com
 */

// Load environment variables from .env file if present
require('dotenv').config();

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { HttpProxyAgent } = require('http-proxy-agent');
const sanitizeFilename = require('sanitize-filename');
const { processImage } = require('./utils/imageProcessor');

// Environment configuration
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const MAX_FILE_SIZE = process.env.MAX_FILE_SIZE || 104857600; // 100MB default
const DOWNLOAD_TIMEOUT = process.env.DOWNLOAD_TIMEOUT || 30000; // 30 seconds default
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

const app = express();
const DOWNLOADS_DIR = path.join(__dirname, 'downloads');

// Ensure downloads directory exists
try {
  if (!fs.existsSync(DOWNLOADS_DIR)) {
    fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
  }
} catch (error) {
  console.error('Failed to create downloads directory:', error);
  process.exit(1);
}

// Security middleware
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data:; font-src 'self' https://cdn.jsdelivr.net");
  next();
});

// Middleware
app.use(cors({
  origin: CORS_ORIGIN
}));
app.use(bodyParser.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/downloads', express.static(DOWNLOADS_DIR));

// API Routes
app.post('/api/download', async (req, res) => {
  try {
    const { 
      url, 
      useProxy, 
      proxyUrl, 
      requiresAuth, 
      username, 
      password, 
      processImage: shouldProcessImage,
      imageOptions 
    } = req.body;
    
    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }
    
    // Validate URL format
    let validatedUrl;
    try {
      validatedUrl = new URL(url).toString();
    } catch (e) {
      return res.status(400).json({ success: false, error: 'Invalid URL format' });
    }
    
    // Configure request options
    const options = {
      // Set reasonable timeout
      timeout: DOWNLOAD_TIMEOUT,
      responseType: 'arraybuffer',
      maxContentLength: MAX_FILE_SIZE,
      maxBodyLength: MAX_FILE_SIZE
    };
    
    // Add proxy if enabled
    if (useProxy && proxyUrl) {
      const isHttps = validatedUrl.startsWith('https');
      options.proxy = false; // Disable axios default proxy behavior
      
      if (isHttps) {
        options.httpsAgent = new HttpsProxyAgent(proxyUrl);
      } else {
        options.httpAgent = new HttpProxyAgent(proxyUrl);
      }
    }
    
    // Add auth if enabled
    if (requiresAuth && username && password) {
      options.auth = {
        username,
        password
      };
    }
    
    // Download the file
    const response = await axios.get(validatedUrl, options);
    
    // Check content type to ensure it's an image or allowed file
    const contentType = response.headers['content-type'] || '';
    const isImage = contentType.startsWith('image/');
    const isMedia = isImage || 
                   contentType.startsWith('video/') || 
                   contentType.startsWith('audio/') ||
                   contentType.includes('application/octet-stream');
    
    if (!isMedia) {
      console.warn(`Potentially unsafe content type: ${contentType}`);
    }
    
    // Get filename from URL or Content-Disposition header
    let filename = '';
    
    // Try Content-Disposition header first
    const contentDisposition = response.headers['content-disposition'];
    if (contentDisposition) {
      const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
      if (filenameMatch && filenameMatch[1]) {
        filename = filenameMatch[1].replace(/['"]/g, '');
      }
    }
    
    // If no filename from Content-Disposition, extract from URL
    if (!filename) {
      try {
        const urlObj = new URL(validatedUrl);
        const urlPath = urlObj.pathname;
        const urlFilename = urlPath.split('/').pop();
        
        if (urlFilename) {
          // Remove query string if present
          filename = urlFilename.split('?')[0];
        }
      } catch (e) {
        // URL parsing failed, use a generic name
        console.warn('URL parsing failed, using generic filename');
      }
    }
    
    // If we still don't have a filename, generate one based on timestamp
    if (!filename) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const ext = getExtensionFromContentType(contentType);
      filename = `download-${timestamp}${ext}`;
    }
    
    // Sanitize filename and ensure it has a valid extension
    filename = sanitizeFilename(filename);
    let fileExt = path.extname(filename).toLowerCase();
    
    // If no extension, try to get from content-type
    if (!fileExt) {
      const ext = getExtensionFromContentType(contentType);
      if (ext) {
        filename += ext;
        fileExt = ext;
      }
    }
    
    // Ensure filename is not empty and has an extension if it's an image
    if (isImage && !fileExt) {
      // Default to .jpg for images without extension
      filename += '.jpg';
    }
    
    // Ensure the filename isn't too long
    if (filename.length > 255) {
      fileExt = path.extname(filename);
      // Truncate but keep extension
      filename = filename.slice(0, 240) + fileExt;
    }
    
    // Handle duplicate filenames
    let finalFilename = filename;
    let filePath = path.join(DOWNLOADS_DIR, finalFilename);
    let counter = 1;
    
    while (fs.existsSync(filePath)) {
      const parsedFilename = path.parse(filename);
      finalFilename = `${parsedFilename.name}_${counter}${parsedFilename.ext}`;
      filePath = path.join(DOWNLOADS_DIR, finalFilename);
      counter++;
    }
    
    // Save the file
    try {
      fs.writeFileSync(filePath, Buffer.from(response.data));
      console.log(`File saved: ${filePath}`);
    } catch (error) {
      console.error('Error saving file:', error);
      return res.status(500).json({
        success: false,
        error: 'Failed to save file'
      });
    }
    
    let finalFilePath = filePath;
    finalFilename = path.basename(filePath);
    
    // Process the image if requested and it's an image
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff', '.svg', '.avif'];
    if (shouldProcessImage && isImage && imageExtensions.includes(path.extname(finalFilename).toLowerCase())) {
      try {
        finalFilePath = await processImage(filePath, imageOptions);
        finalFilename = path.basename(finalFilePath);
      } catch (error) {
        console.error('Image processing error:', error);
        // Continue with the original file if processing fails
      }
    }
    
    // Get file info for response
    const stats = fs.statSync(finalFilePath);
    
    res.json({
      success: true,
      download: {
        filename: finalFilename,
        size: stats.size,
        downloadUrl: `/downloads/${finalFilename}`,
        createdAt: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('Download error:', error);
    
    // Provide appropriate error messages
    if (error.code === 'ECONNABORTED') {
      return res.status(504).json({
        success: false,
        error: 'Download timed out. Try again or use a proxy.'
      });
    }
    
    if (error.response) {
      // Server responded with non-2xx status
      return res.status(error.response.status).json({
        success: false,
        error: `Server responded with ${error.response.status}: ${error.response.statusText}`
      });
    }
    
    if (error.request) {
      // No response received
      return res.status(502).json({
        success: false,
        error: 'No response received from server. Check the URL or try using a proxy.'
      });
    }
    
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to download file'
    });
  }
});

// Helper function to get file extension from content type
function getExtensionFromContentType(contentType) {
  const contentTypeMap = {
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/png': '.png',
    'image/gif': '.gif',
    'image/webp': '.webp',
    'image/bmp': '.bmp',
    'image/tiff': '.tiff',
    'image/svg+xml': '.svg',
    'image/avif': '.avif',
    'video/mp4': '.mp4',
    'video/webm': '.webm',
    'video/avi': '.avi',
    'video/quicktime': '.mov',
    'video/x-matroska': '.mkv',
    'audio/mpeg': '.mp3',
    'audio/mp4': '.m4a',
    'audio/wav': '.wav',
    'audio/webm': '.weba',
    'application/pdf': '.pdf',
    'application/zip': '.zip'
  };
  
  const type = contentType.split(';')[0].trim().toLowerCase();
  return contentTypeMap[type] || '';
}

// Get list of downloads
app.get('/api/downloads', (req, res) => {
  try {
    const files = fs.readdirSync(DOWNLOADS_DIR);
    const downloads = files.map(filename => {
      const filePath = path.join(DOWNLOADS_DIR, filename);
      const stats = fs.statSync(filePath);
      
      return {
        filename,
        size: stats.size,
        downloadUrl: `/downloads/${filename}`,
        createdAt: stats.mtime.toISOString()
      };
    });
    
    res.json({
      success: true,
      downloads
    });
  } catch (error) {
    console.error('Error listing downloads:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to list downloads'
    });
  }
});

// Delete a download
app.delete('/api/downloads/:filename', (req, res) => {
  try {
    const { filename } = req.params;
    // Sanitize filename to prevent path traversal
    const sanitizedFilename = sanitizeFilename(filename);
    const filePath = path.join(DOWNLOADS_DIR, sanitizedFilename);
    
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      res.json({ success: true });
    } else {
      res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }
  } catch (error) {
    console.error('Error deleting file:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete file'
    });
  }
});

// Handle 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Resource not found'
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    error: NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Lackadaisical Image Downloader server running in ${NODE_ENV} mode on port ${PORT}`);
});