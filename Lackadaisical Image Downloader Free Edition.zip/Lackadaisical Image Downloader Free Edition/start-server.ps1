# Lackadaisical Image Downloader - Server Launcher (PowerShell)
$ErrorActionPreference = "Stop"

# Display header
Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  Lackadaisical Image Downloader - Server Launcher" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# Define port
$PORT = 3000

# Check if .env file exists, create it if not
$envFile = Join-Path $PWD ".env"
if (-not (Test-Path $envFile)) {
    Write-Host "Creating .env file with default settings..." -ForegroundColor Yellow
    
    $envContent = @"
# Lackadaisical Image Downloader - Environment Configuration

# Server port
PORT=3000

# Environment (development or production)
NODE_ENV=production

# Maximum file size for download in bytes (100MB)
MAX_FILE_SIZE=104857600

# Download timeout in milliseconds (30 seconds)
DOWNLOAD_TIMEOUT=30000

# CORS settings (use * for development, specific domains for production)
CORS_ORIGIN=*

# Downloads directory (relative to project root)
DOWNLOADS_DIR=downloads
"@
    
    try {
        Set-Content -Path $envFile -Value $envContent
        Write-Host ".env file created successfully." -ForegroundColor Green
    } catch {
        Write-Host "Error creating .env file: $_" -ForegroundColor Red
        Write-Host "The server may still work, but some features might be limited." -ForegroundColor Yellow
    }
    Write-Host ""
}

# Check if Node.js is installed
try {
    $nodeVersion = node -v
    Write-Host "Node.js version: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "Error: Node.js is not installed or not in PATH. Please install Node.js to run this application." -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# Check if the port is already in use
$portInUse = Get-NetTCPConnection -LocalPort $PORT -ErrorAction SilentlyContinue
if ($portInUse) {
    Write-Host "Warning: Port $PORT is already in use." -ForegroundColor Yellow
    Write-Host "The server may already be running, or another application is using this port." -ForegroundColor Yellow
    
    $response = Read-Host "Do you want to continue anyway? (y/n)"
    if ($response -ne "y") {
        Write-Host "Exiting..." -ForegroundColor Yellow
        exit 0
    }
}

# Set environment variables
$env:PORT = $PORT
$env:NODE_ENV = "production"

Write-Host "Starting server on http://localhost:$PORT" -ForegroundColor Cyan
Write-Host ""

# Start the server in a new PowerShell window
try {
    Start-Process powershell -ArgumentList "-Command & {Set-Location '$PWD'; `$env:PORT=$PORT; `$env:NODE_ENV='production'; node server.js; Read-Host 'Press Enter to close server'}"
    Write-Host "Server process started successfully!" -ForegroundColor Green
} catch {
    Write-Host "Failed to start server: $_" -ForegroundColor Red
    exit 1
}

# Wait for server to initialize
Write-Host "Waiting for server to initialize..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

# Open the browser
try {
    Start-Process "http://localhost:$PORT"
    Write-Host "Browser opened to http://localhost:$PORT" -ForegroundColor Green
} catch {
    Write-Host "Failed to open browser, but server is running. You can access it at http://localhost:$PORT" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Server is running in a separate window." -ForegroundColor Green
Write-Host "To stop the server, close that window or run stop-server.ps1" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press any key to close this window..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 