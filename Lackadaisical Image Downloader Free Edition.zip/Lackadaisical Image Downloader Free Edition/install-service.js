/**
 * Windows Service Installer for Lackadaisical Image Downloader
 * 
 * This script creates a Windows service for the application
 * Prerequisites: Run the following commands before executing this script
 *   npm install -g node-windows
 *   npm link node-windows
 */

const Service = require('node-windows').Service;
const path = require('path');
const EventLogger = require('node-windows').EventLogger;
const fs = require('fs');

// Check if .env file exists, create it if not
const envFilePath = path.join(__dirname, '.env');
if (!fs.existsSync(envFilePath)) {
  console.log('Creating .env file with default settings...');

  const envContent = `# Lackadaisical Image Downloader - Environment Configuration

# Server port
PORT=3000

# Environment (development or production)
NODE_ENV=production

# Maximum file size for download in bytes (100MB)
MAX_FILE_SIZE=104857600

# Download timeout in milliseconds (30 seconds)
DOWNLOAD_TIMEOUT=30000

# CORS settings (use * for development, specific domains for production)
CORS_ORIGIN=*

# Downloads directory (relative to project root)
DOWNLOADS_DIR=downloads
`;

  try {
    fs.writeFileSync(envFilePath, envContent);
    console.log('.env file created successfully.');
  } catch (error) {
    console.error('Error creating .env file:', error);
    console.warn('The service may still work, but some features might be limited.');
  }
  console.log();
}

// Read environment variables from .env file
let envVars = [
  { name: 'NODE_ENV', value: 'production' },
  { name: 'PORT', value: 3000 },
  { name: 'MAX_FILE_SIZE', value: 104857600 },
  { name: 'DOWNLOAD_TIMEOUT', value: 30000 },
  { name: 'CORS_ORIGIN', value: '*' }
];

// Try to read from .env if it exists
if (fs.existsSync(envFilePath)) {
  try {
    const envContent = fs.readFileSync(envFilePath, 'utf8');
    const lines = envContent.split('\n');
    
    for (const line of lines) {
      // Skip comments and empty lines
      if (line.trim().startsWith('#') || !line.trim()) continue;
      
      // Extract key-value pairs
      const match = line.match(/^([^=]+)=(.*)$/);
      if (match) {
        const key = match[1].trim();
        const value = match[2].trim();
        
        // Update existing env var or add new one
        const existing = envVars.find(v => v.name === key);
        if (existing) {
          existing.value = value;
        } else {
          envVars.push({ name: key, value });
        }
      }
    }
    
    console.log('Loaded configuration from .env file.');
  } catch (error) {
    console.error('Error reading .env file:', error);
    console.warn('Using default configuration.');
  }
}

// Create a new service object
const svc = new Service({
  name: 'Lackadaisical Image Downloader',
  description: 'A secure image downloader service with proxy and authentication support',
  script: path.join(__dirname, 'server.js'),
  nodeOptions: [],
  workingDirectory: __dirname,
  allowServiceLogon: true,
  
  // Service environment variables
  env: envVars
});

// Event handlers
svc.on('install', function() {
  console.log('Service installed successfully');
  console.log('Starting service...');
  svc.start();
});

svc.on('start', function() {
  console.log('Service started successfully');
  console.log('Visit http://localhost:3000 to access the application');
});

svc.on('alreadyinstalled', function() {
  console.log('Service is already installed');
});

svc.on('invalidinstallation', function() {
  console.error('Invalid installation, check prerequisites');
});

svc.on('error', function(err) {
  console.error('Error:', err);
});

// Install the service
console.log('Installing service...');
svc.install();

// Create uninstall script (for reference)
console.log('To uninstall the service, create a file named "uninstall-service.js" with the following content:');
console.log(`
const Service = require('node-windows').Service;
const path = require('path');

const svc = new Service({
  name: 'Lackadaisical Image Downloader',
  script: path.join(__dirname, 'server.js')
});

svc.on('uninstall', function() {
  console.log('Service removed successfully');
});

console.log('Uninstalling service...');
svc.uninstall();
`); 