# Lackadaisical Image Downloader - Server Shutdown (PowerShell)
$ErrorActionPreference = "Stop"

# Display header
Write-Host ""
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host "  Lackadaisical Image Downloader - Server Shutdown" -ForegroundColor Cyan
Write-Host "=====================================================" -ForegroundColor Cyan
Write-Host ""

# Define port
$PORT = 3000

Write-Host "Looking for server process on port $PORT..." -ForegroundColor Yellow

# Try to find the process using the specified port
$connections = Get-NetTCPConnection -LocalPort $PORT -State Listen -ErrorAction SilentlyContinue
if ($connections) {
    foreach ($connection in $connections) {
        $processId = $connection.OwningProcess
        $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
        
        if ($process) {
            $processName = $process.Name
            $processPath = $process.Path
            
            # Only kill node processes to be safe
            if ($processName -eq "node" -or $processName -eq "nodejs") {
                Write-Host "Found Node.js server process (PID: $processId) running on port $PORT" -ForegroundColor Green
                Write-Host "Stopping process..." -ForegroundColor Yellow
                
                try {
                    Stop-Process -Id $processId -Force
                    Write-Host "Server shutdown successful!" -ForegroundColor Green
                } catch {
                    Write-Host "Failed to stop server process: $_" -ForegroundColor Red
                    Write-Host "You may need to manually close the process." -ForegroundColor Red
                }
            } else {
                Write-Host "Warning: Found non-Node.js process ($processName, PID: $processId) on port $PORT" -ForegroundColor Yellow
                $response = Read-Host "This doesn't appear to be our server. Stop it anyway? (y/n)"
                if ($response -eq "y") {
                    try {
                        Stop-Process -Id $processId -Force
                        Write-Host "Process stopped." -ForegroundColor Green
                    } catch {
                        Write-Host "Failed to stop process: $_" -ForegroundColor Red
                    }
                } else {
                    Write-Host "Process not stopped." -ForegroundColor Yellow
                }
            }
        }
    }
} else {
    Write-Host "No process found listening on port $PORT." -ForegroundColor Yellow
    
    # Look for any Node.js processes that might be our server
    $nodeProcesses = Get-Process | Where-Object { $_.Name -eq "node" -or $_.Name -eq "nodejs" }
    if ($nodeProcesses) {
        Write-Host "Found Node.js processes that might be our server:" -ForegroundColor Yellow
        foreach ($proc in $nodeProcesses) {
            Write-Host "  PID: $($proc.Id), Command: $($proc.CommandLine)" -ForegroundColor Yellow
        }
        
        $response = Read-Host "Do you want to stop all Node.js processes? (y/n)"
        if ($response -eq "y") {
            try {
                Stop-Process -Name "node" -Force
                Write-Host "All Node.js processes stopped." -ForegroundColor Green
            } catch {
                Write-Host "Failed to stop Node.js processes: $_" -ForegroundColor Red
            }
        }
    } else {
        Write-Host "No Node.js processes found running." -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 